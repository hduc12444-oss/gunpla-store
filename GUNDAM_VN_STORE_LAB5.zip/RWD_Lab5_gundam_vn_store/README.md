# gundam.vn store — RWD Lab 5

## Chạy website
1. Giải nén thư mục dự án.
2. Mở thư mục bằng Visual Studio Code.
3. Cài extension Live Server (nếu chưa có).
4. Nhấp phải `index.html` → **Open with Live Server**.

## Cấu trúc
- `index.html`: Trang chủ, 8 card sản phẩm render từ mảng JavaScript.
- `pages/about.html`: Giới thiệu.
- `pages/contact.html`: Form liên hệ và lưu `contactMessages` vào localStorage.
- `assets/css/styles.css`: Giao diện mobile-first, breakpoint tablet/desktop.
- `assets/js/app.js`: Dark Mode, menu mobile, Back-to-Top, tìm kiếm/lọc, validate form.
- `assets/img/original/`: Ảnh JPG gốc.
- `assets/img/optimized/`: Ảnh WebP đã tối ưu.

## Kiểm tra localStorage
Gửi form hợp lệ, mở DevTools → Application → Local Storage → địa chỉ localhost → `contactMessages`. Có thể xem thêm trong Console bằng `JSON.parse(localStorage.getItem('contactMessages'))`.

## Deploy GitHub Pages
1. Tạo repository GitHub mới và upload toàn bộ nội dung trong thư mục dự án.
2. Vào **Settings → Pages**.
3. Trong **Build and deployment**, chọn **Deploy from a branch**.
4. Chọn branch `main`, folder `/ (root)` rồi Save.
5. Đợi GitHub Pages xuất bản, mở URL được cung cấp. Không dùng đường dẫn file máy tính.

## Ghi chú
- Tên miền `gundam.vn` trong giao diện là tên thương hiệu demo, không có nghĩa website đã sở hữu tên miền hoặc đã được xuất bản.
- Giá và sản phẩm là dữ liệu minh họa phục vụ bài tập, không phải báo giá bán hàng thực tế.
- Ảnh minh họa được tạo riêng cho project theo phong cách mecha nguyên bản.
